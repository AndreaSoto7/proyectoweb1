from rest_framework import serializers, viewsets
from rest_framework.permissions import IsAuthenticated
from cursos.models import Cursos

class CursoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cursos
        fields = '__all__'

class CursoViewset(viewsets.ModelViewSet):
    serializer_class = CursoSerializer
    queryset = Cursos.objects.all()
    #permission_classes = [IsAuthenticated]
