from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
import re
from rest_framework import status
from rest_framework.exceptions import NotFound
from rest_framework.response import Response
from rest_framework.views import APIView
from cursos.api.cursos_viewset import CursoSerializer
from cursos.models import Matriculacion

def validate_email_format(email):
    regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(regex, email):
        raise ValidationError('El formato del correo electrónico es inválido')

class CreateUserView(APIView):
    @staticmethod
    def post(request):
        first_name = request.data.get('first_name')
        last_name = request.data.get('last_name')
        username = request.data.get('username')
        email = request.data.get('email')
        password = request.data.get('password')

        if not all([first_name, last_name, username, email, password]):
            return Response({'error': 'Todos los campos son requeridos'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            validate_email_format(email)
        except ValidationError:
            return Response({'error': 'El formato del correo electrónico es inválido'}, status=status.HTTP_400_BAD_REQUEST)

        user = User.objects.create_user(username, email, password)
        user.first_name = first_name
        user.last_name = last_name
        user.save()

        return Response({'message': 'Usuario creado con éxito'}, status=status.HTTP_201_CREATED)

class GetCursosUsuarios(APIView):
    @staticmethod
    def get(request, pk):
        try:
            user = User.objects.get(pk=pk)
        except User.DoesNotExist:
            raise NotFound("Usuario no encontrado")

        matriculaciones = Matriculacion.objects.filter(idUser=user)
        cursos = [matriculacion.idCurso for matriculacion in matriculaciones]

        cursos = CursoSerializer(cursos, many=True).data

        return Response(cursos, status=status.HTTP_200_OK)


