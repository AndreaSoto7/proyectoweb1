from rest_framework import serializers, viewsets

from cursos.models import AvanceLecciones

from rest_framework.permissions import IsAuthenticated


# Datos a formato JSON
class AvanceLeccionesSerializer(serializers.ModelSerializer):
    class Meta:
        model = AvanceLecciones
        fields = '__all__'

# Consultas a la base de datos CRUD
class AvanceLeccionesViewset(viewsets.ModelViewSet):
    serializer_class = AvanceLeccionesSerializer
    queryset = AvanceLecciones.objects.all()
    permission_classes = [IsAuthenticated]