from rest_framework import serializers, viewsets
from rest_framework.permissions import IsAuthenticated

from cursos.models import Matriculacion

class MatriculacionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Matriculacion
        fields = '__all__'

class MatriculacionViewset(viewsets.ModelViewSet):
    serializer_class = MatriculacionSerializer
    queryset = Matriculacion.objects.all()
    permission_classes = [IsAuthenticated]
