from rest_framework import serializers, viewsets, status
from rest_framework.response import Response
from cursos.models import Lecciones

class LeccionesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Lecciones
        fields = '__all__'

class LeccionesViewset(viewsets.ModelViewSet):
    serializer_class = LeccionesSerializer
    queryset = Lecciones.objects.all()

    def retrieve(self, request, pk=None):
        queryset = Lecciones.objects.filter(idCurso=pk)
        if not queryset.exists():
            return Response(status=status.HTTP_404_NOT_FOUND)
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)
