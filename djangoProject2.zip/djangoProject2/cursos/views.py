# cursos/views.py
from django.shortcuts import render

def index(request):
    context = {
        'message': 'Hola desde Django!'
    }
    return render(request, 'index.html', context)
