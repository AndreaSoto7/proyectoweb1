from django.contrib.auth.models import User
from django.db import models

from cursos.models import Cursos

class Matriculacion(models.Model):
    idUser = models.ForeignKey(User, on_delete=models.CASCADE)
    idCurso = models.ForeignKey(Cursos, on_delete=models.CASCADE)
