from django.contrib.auth.models import User
from django.db import models

from cursos.models import Lecciones

class AvanceLecciones(models.Model):
    idUser = models.ForeignKey(User, on_delete=models.CASCADE)
    idLeccion = models.ForeignKey(Lecciones, on_delete=models.CASCADE)
    avance = models.FloatField()

    def __str__(self):
        return self.idUser.username
