from django.db import models

from cursos.models import Cursos

class Lecciones(models.Model):
    nombre = models.CharField(max_length=50)
    tipo_leccion = models.TextField()
    imagen = models.TextField()
    idCurso = models.ForeignKey(Cursos, on_delete=models.CASCADE)

    def __str__(self):
        return self.nombre
