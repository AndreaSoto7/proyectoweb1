from django.urls import path, include
from rest_framework import routers
from rest_framework.authtoken.views import obtain_auth_token
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView, TokenVerifyView
from . import views
from cursos.api import CursoViewset, LeccionesViewset, MatriculacionViewset, AvanceLeccionesViewset, CreateUserView, \
    GetCursosUsuarios

router = routers.DefaultRouter()

router.register(r'cursos', CursoViewset)
router.register(r'lecciones', LeccionesViewset)
router.register(r'matriculacion', MatriculacionViewset)
router.register(r'avance', AvanceLeccionesViewset)

urlpatterns = [
    path('', include(router.urls)),
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('token/verify/', TokenVerifyView.as_view(), name='token_verify'),  # opcional
    path('api-token-auth/', obtain_auth_token),
    path('lecciones/<int:pk>/', LeccionesViewset.as_view({'get': 'retrieve'}), name='lecciones-by-course'),
    path('user/', CreateUserView.as_view(), name='create_user'),
    path('user/cursos/<pk>/', GetCursosUsuarios.as_view(), name='get_cursos_usuarios'),

]